 * 1.0.0 - Erste Veröffentlichung
 * 1.0.1 - Saison 2014
 * 1.0.2 - Fehlerbehandlung optimiert
 * 1.1   - Umstellung auf JSON API von openligadb, Laden der Tabelle per AJAX, Hervorheben eines Vereins und Updater
 * 1.2   - Bugfixes
 * 1.3   - Saison 2015/2016 als Standard
 * 1.4   - Keine PHP Notices mehr, AJAX Endpoint static und Versionsnummer im HTML Kommentar
 * 1.5   - Fehler Spieltag 1, falsches Logo St. Pauli, 3 Punkte Strafe Sandhausen 2015
 * 1.6   - Saison 2016
 * 1.7   - Ungewollten Output von anderen Plugins wie GoogleAnalytics oder PHP Meldungen im Ajax Response ignorieren
 * 1.8   - Domain geändert
 * 1.9   - Umgestellt auf HTTPS und CURL
 * 1.10  - feste CSS Breite für Bilder
 * 1.11  - Saison 2017/2018
 * 1.12  - Neue Bezeichnungen für Bayern und Leverkusen, Cache-Datei löschen bei Update
 * 1.13  - Saison 2018/2019
 * 1.16  - Sasion 2019/2020
